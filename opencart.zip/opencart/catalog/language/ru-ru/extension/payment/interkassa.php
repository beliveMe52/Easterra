<?php
// Text
$_['text_ik_payment_desc']        = 'Оплата заказа №%s';

$_['text_comment']                = 'Интеркасса: %s. Сумма: %s.';
$_['text_comment_fail']           = 'Интеркасса: оплата не удалась.';

$_['text_error_ik_sign_hash']     = 'Некорректная подпись сообщения от платёжного шлюза';
$_['text_error_order_not_found']  = 'Заказ № "%s" не найден';

$_['text_payment'] = 'Оплатить';
$_['text_select_payment_method'] = 'Выберите удобный способ оплаты';
$_['text_select_currency'] = 'Укажите валюту';
$_['text_press_pay'] = 'Нажмите &laquo;Оплатить&raquo;';
$_['text_pay_through'] = 'Оплатить через';
$_['text_not_selected_currency'] = 'Вы не выбрали валюту';
$_['text_something_wrong'] = 'Что-то пошло не так';